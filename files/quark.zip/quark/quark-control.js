function darkMode(){
	const body = document.getElementById("body");
	body.classList.toggle("dark-mode");
}

